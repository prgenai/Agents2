import time
import asyncio
from typing import Dict, Tuple, Optional
from .interfaces import BaseSessionManager


class InMemorySessionManager(BaseSessionManager):
    """
    Thread-safe In-Memory implementation.
    Suitable for single-instance deployments or testing.
    """

    def __init__(self):
        # { session_id: (model_id, expiration_timestamp) }
        self._store: Dict[str, Tuple[str, float]] = {}
        self._lock = asyncio.Lock()

    async def get_affinity(self, session_id: str) -> Optional[str]:
        async with self._lock:
            if session_id not in self._store:
                return None

            model_id, expires_at = self._store[session_id]

            # Lazy Expiration Check
            if time.time() > expires_at:
                del self._store[session_id]
                return None

            return model_id

    async def set_affinity(self, session_id: str, model_id: str, ttl_seconds: int = 1800):
        async with self._lock:
            expires_at = time.time() + ttl_seconds
            self._store[session_id] = (model_id, expires_at)