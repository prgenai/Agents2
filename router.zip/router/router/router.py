import yaml
import time
import random
import logging
import asyncio
from typing import Dict, List, Any, Callable, Awaitable, AsyncIterator

from tenacity import retry, stop_after_attempt, wait_exponential, retry_if_exception_type

# Internal imports
from .interfaces import BaseFluxRouter, BaseSessionManager, ModelConfig
from .session_manager import InMemorySessionManager

logger = logging.getLogger("FluxRouter")


class GlobalCooldownError(Exception):
    pass


class FluxModelRouter(BaseFluxRouter):
    def __init__(self, config_path: str):
        # 1. Load Config
        self.config = self._load_config(config_path)

        # 2. Initialize Session Manager
        self.session_manager = self._init_session_manager(self.config)

        # 3. Parse Models & Groups
        self.models = {m["id"]: ModelConfig(**m) for m in self.config.get("models", [])}
        self.groups = self.config.get("groups", {"default": list(self.models.keys())})

        # 4. Resilience Settings
        res = self.config.get("resilience", {})
        self.cooldown_seconds = res.get("global_cooldown_seconds", 60)
        self.max_retries = res.get("max_retries", 3)
        self.sticky_ttl = res.get("sticky_ttl_minutes", 30) * 60

        # State
        self.cooldowns: Dict[str, float] = {}
        logger.info(f"🚀 Flux Router initialized with {len(self.models)} models.")

    def _load_config(self, path: str) -> Dict[str, Any]:
        try:
            with open(path, "r") as f:
                return yaml.safe_load(f)
        except Exception as e:
            raise RuntimeError(f"Failed to load Flux config: {e}")

    def _init_session_manager(self, config: Dict) -> BaseSessionManager:
        s_type = config.get("storage", {}).get("type", "memory")
        if s_type == "memory":
            return InMemorySessionManager()
        else:
            raise ValueError(f"Unknown storage type: {s_type}")

    # --- Cooldown Logic ---
    def _is_cooling_down(self, model_id: str) -> bool:
        if model_id in self.cooldowns:
            if time.time() < self.cooldowns[model_id]:
                return True
            else:
                del self.cooldowns[model_id]  # Expired
        return False

    def _trigger_cooldown(self, model_id: str):
        logger.warning(f"🔥 Triggering Cooldown for {model_id}")
        self.cooldowns[model_id] = time.time() + self.cooldown_seconds

    # --- Selection Logic ---
    async def _get_candidate(self, session_id: str, group: str) -> ModelConfig:
        group_ids = self.groups.get(group, [])
        if not group_ids:
            raise ValueError(f"Group {group} is empty")

        # 1. Check Stickiness
        sticky_id = await self.session_manager.get_affinity(session_id)
        if sticky_id and sticky_id in group_ids and not self._is_cooling_down(sticky_id):
            return self.models[sticky_id]

        # 2. Select Healthy Candidate (Round Robin/Random)
        healthy_ids = [mid for mid in group_ids if not self._is_cooling_down(mid)]

        if not healthy_ids:
            raise GlobalCooldownError("All models are in cooldown!")

        selected_id = random.choice(healthy_ids)

        # 3. Update Stickiness
        await self.session_manager.set_affinity(session_id, selected_id, self.sticky_ttl)
        return self.models[selected_id]

    # --- EXECUTE (Request/Response) ---
    async def route_and_execute(self, session_id, execution_callback, group="default", _depth=0):
        if _depth > 3: raise GlobalCooldownError("Max failover depth reached.")

        target_model = await self._get_candidate(session_id, group)

        @retry(stop=stop_after_attempt(self.max_retries), wait=wait_exponential(multiplier=1, min=1), reraise=True)
        async def _attempt():
            return await execution_callback(target_model)

        try:
            return await _attempt()
        except Exception as e:
            logger.error(f"❌ Execution failed on {target_model.id}: {e}")
            self._trigger_cooldown(target_model.id)
            # Recursive Failover
            return await self.route_and_execute(session_id, execution_callback, group, _depth + 1)

    # --- STREAM (Generators) ---
    async def route_and_stream(self, session_id, execution_callback, group="default", _depth=0):
        if _depth > 3: raise GlobalCooldownError("Max failover depth reached.")

        target_model = await self._get_candidate(session_id, group)

        @retry(stop=stop_after_attempt(3), wait=wait_exponential(multiplier=1, min=1), reraise=True)
        async def _create_stream_conn():
            # Only retries the connection setup
            return await execution_callback(target_model)

        try:
            stream_iterator = await _create_stream_conn()
            async for chunk in stream_iterator:
                yield chunk
        except Exception as e:
            logger.error(f"❌ Stream failed on {target_model.id}: {e}")
            self._trigger_cooldown(target_model.id)
            # Recursive Failover
            async for chunk in self.route_and_stream(session_id, execution_callback, group, _depth + 1):
                yield chunk