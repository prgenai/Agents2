from abc import ABC, abstractmethod
from typing import Optional, List, Dict, Any, Callable, Awaitable, AsyncIterator
from dataclasses import dataclass

@dataclass
class ModelConfig:
    id: str
    provider: str
    model_name: str
    api_key: Optional[str] = None
    parameters: Optional[Dict[str, Any]] = None

class BaseSessionManager(ABC):
    """Contract for Sticky Session Storage"""
    @abstractmethod
    async def get_affinity(self, session_id: str) -> Optional[str]:
        pass

    @abstractmethod
    async def set_affinity(self, session_id: str, model_id: str, ttl_seconds: int):
        pass

class BaseTachyonRouter(ABC):
    """Contract for the Core Router"""
    @abstractmethod
    async def route_and_execute(
        self,
        session_id: str,
        execution_callback: Callable[[ModelConfig], Awaitable[Any]],
        group: str = "default"
    ) -> Any:
        pass

    @abstractmethod
    async def route_and_stream(
        self,
        session_id: str,
        execution_callback: Callable[[ModelConfig], Awaitable[AsyncIterator[Any]]],
        group: str = "default"
    ) -> AsyncIterator[Any]:
        pass