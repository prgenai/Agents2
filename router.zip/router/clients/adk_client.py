import logging
from typing import Any, Optional, Union, List
from google.genai.types import GenerateContentResponse, Candidate, Content, Part
from FLux.router.interfaces import ModelConfig, BaseFLuxRouter

logger = logging.getLogger("FLuxADK")


class FLuxADKClient:
    """
    Simulates a Google ADK Model but routes via FLux.
    """

    def __init__(self, router: BaseFLuxRouter, model_group: str = "default"):
        self.router = router
        self.group = model_group
        self.model_name = "FLux-router"  # ADK expects this property

    async def async_generate_content(
            self,
            contents: Union[str, List[Content]],
            config: Optional[Any] = None,
            **kwargs
    ) -> GenerateContentResponse:

        # 1. Extract Session ID
        session_id = kwargs.get("session_id", "default")
        if config and hasattr(config, "metadata"):
            session_id = config.metadata.get("session_id", session_id)

        # 2. Define Callback
        async def _execute_model_logic(model_conf: ModelConfig):
            logger.info(f"⚡ FLux executing ADK request with: {model_conf.id}")

            # --- ADAPTER LOGIC ---
            # Using LiteLLM to handle the actual call in OpenAI format
            # This is the "Trojan Horse" - converting ADK input to LiteLLM
            import litellm

            # Convert ADK contents to LiteLLM messages
            messages = self._convert_adk_to_litellm(contents)

            response = await litellm.acompletion(
                model=model_conf.model_name,
                api_key=model_conf.api_key,
                messages=messages,
                base_url=model_conf.parameters.get("base_url") if model_conf.parameters else None
            )
            return response.choices[0].message.content

        # 3. Execute
        result_text = await self.router.route_and_execute(
            session_id=session_id,
            execution_callback=_execute_model_logic,
            group=self.group
        )

        # 4. Convert back to ADK Response
        return GenerateContentResponse(
            candidates=[Candidate(content=Content(parts=[Part(text=result_text)]))]
        )

    def _convert_adk_to_litellm(self, contents: Any) -> List[dict]:
        # Simple text conversion for brevity
        if isinstance(contents, str):
            return [{"role": "user", "content": contents}]
        # Add full Content object parsing here if needed
        return [{"role": "user", "content": str(contents)}]