import asyncio
from typing import List, Any, AsyncIterator, Optional, Dict

from langchain_core.language_models import BaseChatModel
from langchain_core.messages import BaseMessage, AIMessage, AIMessageChunk
from langchain_core.outputs import ChatResult, ChatGeneration, ChatGenerationChunk
from langchain_core.callbacks import CallbackManagerForLLMRun

from Flux.router.interfaces import BaseFluxRouter, ModelConfig


class FluxLangChainClient(BaseChatModel):
    router: BaseFluxRouter
    model_group: str = "default"

    @property
    def _llm_type(self) -> str:
        return "Flux-router"

    async def _astream(
            self,
            messages: List[BaseMessage],
            stop: Optional[List[str]] = None,
            run_manager: Optional[CallbackManagerForLLMRun] = None,
            **kwargs
    ) -> AsyncIterator[ChatGenerationChunk]:

        session_id = kwargs.get("session_id", "default")
        params = self._get_model_parameters(stop, **kwargs)

        # Router Callback
        async def _streaming_callback(model_conf: ModelConfig) -> AsyncIterator[Any]:
            import litellm
            litellm_messages = self._convert_messages(messages)

            return await litellm.acompletion(
                model=model_conf.model_name,
                api_key=model_conf.api_key,
                messages=litellm_messages,
                stream=True,
                **params
            )

        stream_generator = self.router.route_and_stream(
            session_id=session_id,
            execution_callback=_streaming_callback,
            group=self.model_group
        )

        async for chunk in stream_generator:
            delta = chunk.choices[0].delta.content or ""
            lc_chunk = ChatGenerationChunk(message=AIMessageChunk(content=delta))

            if run_manager:
                await run_manager.on_llm_new_token(token=delta, chunk=lc_chunk)
            yield lc_chunk

    # --- Wrapper for Non-Streaming ---
    async def _agenerate(self, messages, stop=None, run_manager=None, **kwargs):
        final_content = ""
        async for chunk in self._astream(messages, stop, run_manager, **kwargs):
            final_content += chunk.message.content
        return ChatResult(generations=[ChatGeneration(message=AIMessage(content=final_content))])

    def _generate(self, messages, stop=None, run_manager=None, **kwargs):
        import asyncio
        return asyncio.run(self._agenerate(messages, stop, run_manager, **kwargs))

    # --- Helpers ---
    def _convert_messages(self, messages: List[BaseMessage]) -> List[Dict]:
        formatted = []
        for m in messages:
            role = "user"
            if m.type == "ai":
                role = "assistant"
            elif m.type == "system":
                role = "system"
            formatted.append({"role": role, "content": m.content})
        return formatted

    def _get_model_parameters(self, stop, **kwargs):
        p = kwargs.copy()
        if stop: p["stop"] = stop
        return p