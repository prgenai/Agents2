import asyncio
import logging
from Flux.router.router import FluxModelRouter
from Flux.clients.adk_client import FluxADKClient
from Flux.clients.langchain_client import FluxLangChainClient

# Setup Logging
logging.basicConfig(level=logging.INFO)

async def main():
    # 1. Initialize Router (Loads config.yaml automatically)
    router = FluxModelRouter(config_path="config.yaml")

    print("\n--- TEST 1: Google ADK Client ---")
    adk_client = FluxADKClient(router)
    response = await adk_client.async_generate_content(
        "Hello ADK!", 
        config={"metadata": {"session_id": "user_123"}}
    )
    print(f"ADK Response: {response.candidates[0].content.parts[0].text}")

    print("\n--- TEST 2: LangChain Client (Streaming) ---")
    lc_client = FluxLangChainClient(router=router)
    print("LangChain Stream: ", end="")
    async for chunk in lc_client.astream("Tell me a quick joke", session_id="user_123"):
        print(chunk.content, end="", flush=True)
    print("\n")

if __name__ == "__main__":
    asyncio.run(main())