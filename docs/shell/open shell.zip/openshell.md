# NVIDIA OpenShell

## What is OpenShell?

OpenShell is an open-source sandbox platform that runs AI agents safely. Released by NVIDIA, it isolates AI agents from your system using kernel-level security features. This means the agent can do its job — read files, call APIs, make model inferences — without being able to steal your data, exfiltrate secrets, or break into other parts of your machine.

OpenShell works with any AI agent framework that can run inside a container. It's been tested with OpenClaw, Claude, GPT-4, and custom agents. The key insight is simple: don't trust the agent to police itself. Lock it down at the kernel level instead.

![Diagram](./diagrams/diagram-0.svg)

---

## The Problem No One Was Talking About

AI agents are powerful but dangerous. They can access files, call APIs, run code, and talk to the internet. By default, they run with your full permissions. If the agent gets compromised — whether through a malicious plugin, a prompt injection attack, or a bug in the agent framework — it has the keys to your kingdom.

Real incidents show this is not theoretical. OpenClaw had 2 CVEs that let malicious plugins steal credentials. Over 30,000 instances of vulnerable agent frameworks were exposed publicly on GitHub. Alibaba's ROME agent was found exfiltrating user data. Malicious Slack bot plugins have logged chat messages. This is happening now.

Most solutions try to solve this in software: guardrails in prompts, model safety training, plugin vetting. These are all good, but they all share the same weakness. If the attacker controls what the agent sees or can manipulate the agent's reasoning, these defenses fall apart.

OpenShell takes a different approach. It doesn't ask the agent to be good. It makes it impossible for a bad agent to do damage.

![Diagram](./diagrams/diagram-1.svg)

---

## The Two Core Parts

OpenShell has two separate pieces: a Gateway and a Sandbox. They run as separate processes on your machine. This separation is deliberate.

The **Gateway** is the control plane. It runs with your privileges and keeps your secrets. It decides what the sandbox can do. It holds your API keys, applies your policies, and logs everything. You control the Gateway.

The **Sandbox** is the data plane. It's where the agent actually runs. At creation time, the Gateway applies kernel-level restrictions: file access limits, network isolation, system call filtering. Once the agent starts, these locks cannot be undone from inside the sandbox. The agent cannot grant itself new permissions.

This separation means the agent can never reach the Gateway. Even if it breaks out of its container, it's in an isolated network namespace on the host. Even if it somehow compromises the host kernel, the restrictions were set at creation time by a process that ran with full privileges, and those restrictions are enforced at every system call.

Setting it up takes one command. The Gateway and Sandbox talk over a secure API. Everything the agent does is logged and auditable.

![Diagram](./diagrams/diagram-2.svg)

### Gateway — The Control Room

The Gateway runs on your machine with your permissions. It handles:

- **Sandbox Lifecycle** — creates, starts, stops, and destroys sandboxes
- **Policy Engine** — runs Open Policy Agent (OPA) to evaluate rules
- **Credential Store** — holds your API keys, database passwords, and other secrets
- **Auth Gate** — decides which requests from the sandbox are allowed
- **Audit Log** — records every action the agent takes
- **Operator TUI** — gives you a text interface to control everything

The agent never touches any of this. It cannot read the policy file, steal credentials, or modify logs.

### Sandbox — Where the Agent Lives

The Sandbox is an isolated execution environment. When it starts, the Gateway applies:

- **File access rules** — locks down which paths the agent can read or write
- **System call filters** — blocks dangerous operations like ptrace, mount, and kexec
- **Network isolation** — agent gets its own network namespace, separate from yours
- **Credential injection** — when the agent calls inference.local, the Gateway swaps the agent's credentials with real API keys before the call goes out

The sandbox cannot change these restrictions once it's running.

---

## Everything in One Picture

Before diving into each layer, here's the full architecture. Everything you need to know about how OpenShell works fits into this view.

![Diagram](./diagrams/diagram-2-5.svg)

| Part | Where it runs | What it does |
|------|---|---|
| **Policy Engine (OPA)** | Gateway | Evaluates rules from policy.yaml, decides if requests are allowed |
| **Credential Store** | Gateway | Holds API keys and secrets, never exposed to sandbox |
| **Auth Gate** | Gateway | Checks every request from sandbox before allowing it |
| **Audit Log** | Gateway | Records all sandbox activity, queryable after execution |
| **Operator TUI** | Gateway | Text interface for humans to control the system |
| **AI Agent** | Sandbox | Your agent code running inside the isolated environment |
| **Landlock LSM** | Sandbox | Kernel module that enforces file access rules |
| **seccomp BPF** | Sandbox | Kernel subsystem that filters system calls |
| **Network Namespace** | Sandbox | Kernel feature that gives the sandbox its own network stack |
| **HTTP Proxy** | Sandbox | Intercepts outbound connections, enforces network policy |
| **inference.local** | Sandbox | Fake DNS name that resolves to the Gateway's credential router |
| **Local LLM** | Your machine | Ollama or LM Studio running on the host, reachable through approved paths |
| **Cloud LLM** | The internet | Claude, GPT-4, or other cloud models; agent credentials replaced before call |
| **Approved APIs** | The internet | External services you explicitly allow in the policy |
| **Blocked Endpoints** | The internet | Everything else — rejected by HTTP Proxy + OPA |

---

## Four Layers of Protection

OpenShell uses defense in depth. There are four independent layers, each using a different kernel mechanism. If an attacker bypasses one, the others still protect you.

### Layer 1 — File Access (Landlock)

Landlock is a Linux Security Module (LSM) — a kernel extension point that checks file operations. When the sandbox starts, the Gateway tells the kernel exactly which paths the agent can read and write. The agent cannot see /etc, /home, /root, or ~/.ssh. It can only access /sandbox (for its workspace) and /tmp.

These rules are locked in at creation time. The agent running inside cannot grant itself access to new paths. Even if it calls chmod or tries to trick the kernel, Landlock still says no.

![Diagram](./diagrams/diagram-3a.svg)

### Layer 2 — System Operations (seccomp BPF)

seccomp stands for "secure computing mode." It's a kernel subsystem that filters system calls — the low-level operations that programs use to interact with the OS. When the sandbox starts, the Gateway installs a seccomp filter that runs for every system call made by the agent.

The filter is written in BPF bytecode and runs in the kernel. It blocks ptrace (attaching to other processes), mount (mounting filesystems), clone with NEWUSER (creating hidden user namespaces), perf_event_open (performance monitoring abuse), and kexec (loading a new kernel). These operations could escalate privileges or let the agent escape. The filter says no to all of them.

Because the filter runs in kernel space, the agent cannot remove it, patch it, or work around it. It can only use the system calls that are explicitly allowed.

![Diagram](./diagrams/diagram-3b.svg)

### Layer 3 — Network Isolation (Network Namespace)

A network namespace is a kernel feature that gives the sandbox its own isolated network stack. It's the same feature that Docker and Kubernetes use. The agent's network is completely separate from your machine's network. It cannot see your WiFi, your LAN, or your loopback device.

The only way out of the network namespace is through a single exit point: the HTTP Proxy running inside the sandbox. All outbound connections go through this proxy, which enforces the network policy.

![Diagram](./diagrams/diagram-3c.svg)

### Layer 4 — Outgoing Traffic (HTTP Proxy + OPA)

Every outbound HTTP connection from the agent is intercepted by the HTTP CONNECT proxy. The proxy checks the destination hostname and the HTTP method against rules defined in policy.yaml. These rules are evaluated by Open Policy Agent (OPA), a policy engine that understands your constraints.

For example, you can say: "Agent can call market-api.internal on port 443, methods GET and POST only, from python3 only." Any other request — different hostname, wrong port, DELETE method, wrong binary — gets blocked. The attempt is logged in the audit trail.

Unlike the kernel layers, the network policy can be updated while the sandbox is running. Hot-reload support means you can tighten or loosen the rules without restarting.

![Diagram](./diagrams/diagram-3d.svg)

---

## How AI Model Calls Are Handled

When the agent needs to call an AI model, it makes a request to `inference.local`. This is a fake hostname that only exists inside the sandbox. The Gateway is listening on that name.

The agent includes its own credentials in the request — maybe an API key it thinks it has, or nothing. The Gateway strips out whatever the agent sent. Then it injects the real API key from the Credential Store. Finally, it forwards the request to the actual model endpoint.

This means the agent can be designed to not know about the real API key. The request can go to Claude, GPT-4, or a local LLM like Ollama. From the external service's perspective, the request came from you, not from some untrusted agent. The agent's credentials (if it has any) never leave the sandbox.

You can also send model calls to local LLMs running on your machine. In that case, the data never leaves your network.

![Diagram](./diagrams/diagram-4.svg)

---

## What Happens on Every Request

Here's the journey of a single request from the agent, step by step.

![Diagram](./diagrams/diagram-5.svg)

| Step | Layer | What happens |
|------|-------|---|
| 1 | Agent | Agent tries to do something: open a file, make an API call, run a command |
| 2 | Landlock LSM | Kernel checks if the file path is allowed |
| 3 | seccomp BPF | Kernel checks if the system operation is safe |
| 4 | Network Namespace | Kernel routes the request through the sandbox's isolated network |
| 5 | HTTP Proxy | Proxy intercepts the outbound connection |
| 6 | OPA Rules | Policy engine checks the destination and method against policy.yaml |
| 7a | Allowed path | Request matches a rule: continues to destination or inference.local |
| 7b | Blocked path | Request matches no rule: rejected, written to audit log |
| 8 | Response | If allowed: response returns to the agent through the same path |
| 9 | Audit Log | Everything is recorded, allowed or blocked |

---

## Real Example — A Trading Analysis Agent

Let's build a real example. An agent reads internal market data, generates trading analysis, and summarizes it using a cloud AI model. The market data must never leave your network. API keys stay in the Gateway. The agent is sandboxed.

### The Sandbox Definition

The agent runs in a container. Here's the Dockerfile:

```dockerfile
FROM python:3.11-slim

WORKDIR /sandbox

# Install dependencies
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

# Copy the agent code
COPY agent.py .

# Create workspace directory for data
RUN mkdir -p /workspace/market-data /workspace/reports

# Run the agent
CMD ["python", "agent.py"]
```

The agent code might look like:

```python
import requests
import json

# Read market data from internal API
response = requests.get('https://market-api.internal:443/latest-prices')
market_data = response.json()

# Generate analysis
analysis = f"Market summary: {len(market_data)} records loaded"

# Call cloud AI for summary
ai_response = requests.post(
    'https://inference.local/v1/messages',
    json={
        'model': 'claude-3-5-sonnet-20241022',
        'messages': [{'role': 'user', 'content': f'Summarize: {analysis}'}]
    }
)

summary = ai_response.json()['content'][0]['text']

# Write report
with open('/workspace/reports/summary.txt', 'w') as f:
    f.write(summary)

print("Analysis complete")
```

### The Policy File

The policy file is YAML. It defines what the sandbox can and cannot do. Here's a real policy for this agent:

```yaml
version: "1"

filesystem_policy:
  read_paths:
    - /sandbox
    - /workspace/market-data
    - /workspace/reports
  read_write_paths:
    - /workspace/reports
    - /tmp

process:
  allowed_binaries:
    - /usr/local/bin/python3
    - /usr/bin/python3
    - /bin/sh
    - /usr/bin/curl

network_policies:
  - name: internal-market-api
    destination:
      hostname: market-api.internal
      port: 443
    http_methods: [GET]
    allowed_binaries: [python3]

  - name: inference-local-calls
    destination:
      hostname: inference.local
      port: 443
    http_methods: [POST]
    allowed_binaries: [python3]

  - name: deny-all-else
    destination:
      hostname: "*"
      port: "*"
    http_methods: []
    allowed_binaries: []
```

This policy says:
- Agent can read from /sandbox and market data paths
- Agent can write to /workspace/reports and /tmp
- Allowed binaries: python3, curl, and shell
- Network: GET to market-api.internal, POST to inference.local, nothing else
- Any other connection is blocked

### Starting It Up

Here are the CLI commands to run this agent:

```bash
# Start the Gateway
openshell gateway start --config gateway.yaml

# Create a provider pointing to your local Docker
openshell provider create docker \
  --name local-docker \
  --socket /var/run/docker.sock

# Create the sandbox with the policy
openshell sandbox create \
  --provider local-docker \
  --image trading-agent:latest \
  --policy policy.yaml \
  --name trading-bot
```

The Gateway reads the policy, sets up Landlock, installs the seccomp filter, creates the network namespace, and starts the HTTP proxy. Then it creates the sandbox with the image.

### What Each Layer Does for This Agent

**Landlock**: The agent cannot see the host's /etc, /home, or /root. It only sees /workspace/market-data and /workspace/reports. If it tries to `open('/etc/passwd')`, Landlock says no.

**seccomp**: The agent cannot run `ptrace()` to attach to other processes, cannot `mount()` a filesystem, and cannot use `clone()` with NEWUSER to escalate privileges.

**Network Namespace**: The agent's network is isolated. It cannot see your machine's real network devices or routing table. All its HTTP requests go through the HTTP proxy.

**HTTP Proxy + OPA**: When the agent calls `market-api.internal`, the proxy checks the policy. Hostname matches, port matches, GET is allowed — request goes through. If the agent tries to call `example.com`, no rule matches — blocked immediately.

When the agent calls `inference.local`, the Gateway replaces the agent's API key with the real one from the Credential Store. The request goes to Claude. The market data stays on your network.

![Diagram](./diagrams/diagram-6.svg)

---

## OpenClaw on Its Own vs. OpenClaw with OpenShell

OpenClaw is NVIDIA's agent framework. It's powerful, flexible, and widely used. But by default, it runs with no isolation. The agent has your permissions. The agent can read any file, connect to any server, load any plugin.

If you use OpenClaw without isolation, you're taking on significant risk. If you use it with OpenShell, you're protected.

### What You're Exposing Without OpenShell

Here are the real risks:

| Category | Risk | Impact |
|----------|------|--------|
| **Files** | Agent can read and write any file on your machine | Private keys, customer data, source code — all stolen |
| **Network** | Agent can connect to any server | Exfiltrate data, reach internal services as if it's you |
| **API Keys** | Agent sees all your credentials in environment variables | Keys sold on dark markets, used to impersonate you |
| **Plugins** | Any plugin code runs with your permissions | Malicious plugin steals credentials, loads malware |
| **AI Calls** | Raw data goes to cloud AI with your account | Customer PII, proprietary data, exposed in logs |
| **Logs** | Execution logs contain sensitive data | Accidentally committed to git, exposed in error reports |

### What NemoClaw Adds

NemoClaw is NVIDIA's OpenClaw + OpenShell wrapper. It bundles OpenClaw inside an OpenShell sandbox with sensible defaults. You run one command:

```bash
nemoclaw run --agent my-agent.yaml --policy default.yaml
```

That's it. NemoClaw wraps the agent, creates the sandbox, applies the policy, and runs it.

NemoClaw adds several features on top of base OpenShell:

- **PII Redaction** — automatically removes personal information from data before sending to cloud AI
- **Deny-All Network Policy** — by default, nothing is allowed. You explicitly add what the agent can reach.
- **Intent Verification** — for critical operations, the agent must explain what it's doing and why before the Gateway allows it
- **Cisco AI Defense Skill Vetting** — NemoClaw integrates with Cisco's AI Defense to vet plugin code before the agent loads it

This turns OpenClaw into a safe default. You get the flexibility of OpenClaw without the risk.

![Diagram](./diagrams/diagram-7.svg)

---

## Sources

- [Overview of NVIDIA OpenShell](https://docs.nvidia.com/openshell/latest/about/overview.html)
- [How OpenShell Works](https://docs.nvidia.com/openshell/latest/about/architecture.html)
- [About Gateways and Sandboxes](https://docs.nvidia.com/openshell/latest/sandboxes/index.html)
- [Customize Sandbox Policies](https://docs.nvidia.com/openshell/latest/sandboxes/policies.html)
- [Configure Inference Routing](https://docs.nvidia.com/openshell/latest/inference/configure.html)
- [Policy Schema Reference](https://docs.nvidia.com/openshell/latest/reference/policy-schema.html)
- [NVIDIA OpenShell GitHub](https://github.com/NVIDIA/OpenShell)
- [NVIDIA NemoClaw GitHub](https://github.com/NVIDIA/NemoClaw)
