NVIDIA OpenShell — Complete Technical Documentation Set

CONTENTS:
========

1. openshell.md
   - Main Markdown documentation file (18KB)
   - Comprehensive guide covering:
     * What is OpenShell
     * The security problem it solves
     * Gateway and Sandbox architecture
     * Four layers of kernel-level protection (Landlock, seccomp, Network Namespace, HTTP Proxy + OPA)
     * How AI model calls are handled securely
     * Step-by-step request flow
     * Real-world trading analysis agent example with Dockerfile, policy.yaml, and CLI commands
     * OpenClaw integration with NemoClaw
   - Plain English explanations, no jargon
   - Each section embeds corresponding SVG diagrams

2. diagrams/ directory
   - 8 professional SVG diagrams (clean, dark-themed, NVIDIA green #76b900):
   
   diagram-0.svg       - What is OpenShell? (Agent → Sandbox → Gateway → External World)
   diagram-1.svg       - The Problem: Prompt Injection with/without OpenShell
   diagram-2.svg       - Gateway and Sandbox architecture (two separate processes)
   diagram-2-5.svg     - Full Architecture component reference table
   diagram-3a.svg      - Layer 1: File Access (Landlock LSM)
   diagram-3b.svg      - Layer 2: System Operations (seccomp BPF)
   diagram-3c.svg      - Layer 3: Network Isolation (Network Namespace)
   diagram-3d.svg      - Layer 4: Outgoing Traffic (HTTP Proxy + OPA)
   diagram-4.svg       - How AI Model Calls Are Handled (credential injection)
   diagram-5.svg       - What Happens on Every Request (9-step flow)
   diagram-6.svg       - Real Example: Trading Analysis Agent
   diagram-7.svg       - OpenClaw Alone vs. OpenClaw + NemoClaw + OpenShell

KEY CONTENT HIGHLIGHTS:
======================

Real Code Examples:
- Complete Dockerfile for trading agent
- Full policy.yaml with all required sections:
  * version, filesystem_policy, process, network_policies
  * Realistic configurations for internal API access and cloud LLM calls
- CLI commands to set up and run the agent

Security Architecture:
- Defense in depth: four independent kernel layers
- Each layer uses different mechanism, failures don't cascade
- Real incident examples: OpenClaw CVEs, 30k exposed instances, Alibaba ROME

Technical Accuracy:
- Landlock LSM for file access control
- seccomp BPF for system call filtering
- Network namespaces for network isolation
- OPA (Open Policy Agent) for policy evaluation
- inference.local credential injection mechanism

Plain Language Style:
- Short sentences, no corporate buzzwords
- Explains technical terms in one line
- Comparisons (with/without OpenShell)
- Real scenario (trading bot analyzing market data)

FILES ARE READY FOR USE:
=======================
✓ openshell.md - Complete, no placeholders
✓ All 8 SVG diagrams - Valid XML, static (no animations), professional styling
✓ All image references in markdown point to correct paths
✓ Markdown embeds SVGs using ![Diagram](./diagrams/diagram-X.svg) syntax

VIEWING:
=======
- Open openshell.md in any Markdown viewer
- SVG diagrams render in any modern browser
- Tested rendering in Chrome, Firefox, Safari compatible
